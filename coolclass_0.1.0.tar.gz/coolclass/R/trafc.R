#' Google search history of 51 celebrities.
#'
#' A dataset containing the search patterns of different topics in Google.
#'
#' @format A data frame with 51 rows and 13 variables:
#' \describe{
#'   \item{Celebrities}{name}
#'   \item{modern.dance}{search}
#'   \item{xbox}{search}
#'   \item{ice.fishing}{search}
#'   \item{runny.nose}{search}
#'   \item{prius}{search}
#'   \item{escalade}{search}
#'   \item{college}{search}
#'   \item{retirement}{search}
#'   \item{X401k}{search}
#'   \item{deep.fried}{search}
#'   \item{jello}{search}
#'   \item{vegan}{search}
#'   }

"trafc"
