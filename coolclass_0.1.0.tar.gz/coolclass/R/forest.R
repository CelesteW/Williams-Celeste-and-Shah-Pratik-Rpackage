#' Forest Cover Type
#'
#' A dataset containing the different tree types from four areas within the Roosevelt National Forest in Colorado, including information on tree type, distance to nearby landmarks, soil type, shadow coverage, and typography.
#'
#' @format A data frame with 500 rows and 13 variables:
#' \describe{
#'   \item{Elevation}{Elevation in meters}
#'   \item{Aspect}{Aspect in degrees azimuth}
#'   \item{Slope}{Slope in degrees}
#'   \item{Horizontal_Distance_To_Hydrology}{Horizontal distance to nearest surface water features}
#'   \item{Vertical_Distance_To_Hydrology}{Vertical distance to nearest surface water feautures}
#'   \item{Horizontal_Distance_To_Roadways}{Horizontal distance to nearest roadway}
#'   \item{Hillshade_9am}{Hill shade index at 9am, summer solstice. Value out of 255}
#'   \item{Hillshade_Noon}{Hill shade index at noon, summer solstice. Value out of 255}
#'   \item{Hillshade_3pm}{Hill shade index at 3pm, summer solstice. Value out of 255}
#'   \item{Horizontal_Distance_To_Fire_Points}{Horizontal distance to nearest wildfire ignition points}
#'   \item{Wilderness_Area1}{Wilderness area, 0=absence or 1=presence}
#'   \item{Soil_Type1}{Soil type, 0=absence or 1=presence}
#'   \item{Cover_Type}{Forest cover type}
#'   }

"forest"
