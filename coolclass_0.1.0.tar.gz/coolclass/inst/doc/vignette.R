## ---- include = FALSE----------------------------------------------------
knitr::opts_chunk$set(
	echo = TRUE,
	warning = TRUE,
	message = TRUE,
	comment = "##",
	prompt = FALSE,
	tidy = TRUE,
	tidy.opts = list(blank = FALSE, width.cutoff = 75),
	fig.path = "img/",
	fig.align = "center",
	fig.width= 9,
	fig.height=8
)

## ---- include=FALSE------------------------------------------------------
library(cluster)
library(factoextra)
library(NbClust)

## ------------------------------------------------------------------------
library(coolclass)
str(trafc)

head(trafc) # look at the variables in the data - they're all Google searches of various items that Google's client is interested in for some analysis. They are represented numerically as % increase or decrease in search of particular item.


## ------------------------------------------------------------------------
rownames(trafc) <- trafc[,1]

trafc[,1] <- NULL

head(trafc)

## ------------------------------------------------------------------------
d <- dist(trafc)

head(d) #this would show the distance matrix. Anything that equals 0 is exactly the similar pattern / search preference and as it increases, it is less similar.

## ------------------------------------------------------------------------
fviz_dist(d) 

## ------------------------------------------------------------------------
c <- hclust(d, method = "single") 

c #note that when not specified to R, it by default measures the distance between the observations as per Euclidean distance

plot(c) # Finally, the results are plotted as a dendrogram. The dendrogram displays how items are combined into clusters and is read from the bottom up. Each observation starts as its own cluster. Then the two observations that are closest are combined. 

c <- hclust(d, method = "complete")

## ----fig1, fig.height=9, fig.width=10------------------------------------
plot(c)

c <- hclust(d, method = "average")

plot(c)

## ----fig2, fig.height=9, fig.width=12------------------------------------
c <- hclust(d, method = "centroid")

plot(c)

## ------------------------------------------------------------------------
c <- hclust(d, method = "ward")

plot(c)

## ----fig3, fig.height=5, fig.width=5-------------------------------------
nc <- NbClust(trafc, distance="euclidean",
min.nc=2, max.nc=12, method="average")
table(nc$Best.n[1,])

## ----fig3.2, fig.height=5, fig.width=5-----------------------------------
barplot(table(nc$Best.n[1,]),
xlab="Numer of Clusters", ylab="Number of Criteria",
main="Number of Clusters Chosen by 26 Criteria")


## ------------------------------------------------------------------------
c <- hclust(d, method = "ward")

plot(c)

rect.hclust(c, k = 2, border = "red") # Further integrates the similar observations into k clusters. As the numbebr equaled to k increases, the clusters increases and vice versa.


## ----fig4, fig.height=5, fig.width=5-------------------------------------

nc <- NbClust(trafc, min.nc=2, max.nc=12, method="kmeans")
table(nc$Best.n[1,])

## ----fig5, fig.height=5, fig.width=5-------------------------------------
barplot(table(nc$Best.n[1,]),
xlab="Number of Clusters", ylab="Number of Criteria",
main="Number of Clusters Chosen by 26 Criteria")

set.seed(20)

km <- kmeans(trafc, 4) # Taking into consideration the recommendation by by Nbclust, we try 4 clusters.

km

## ------------------------------------------------------------------------
clusplot(trafc, 
         km$cluster,  
         color = TRUE,  
         lines = 3, 
         labels = 2)    



clusplot(trafc,  
         km$cluster, 
         color = TRUE,  
         lines = 3) 


## ------------------------------------------------------------------------

head(forest)

## ------------------------------------------------------------------------
str(forest)

## ------------------------------------------------------------------------
forest$Cover_Type<- as.factor(forest$Cover_Type)

## ------------------------------------------------------------------------
set.seed(89)
z<- sample(2, nrow(forest), replace = TRUE, prob = c(0.8,0.2))
traindata<- forest[z==1,]
testdata<- forest[z==2,]
dim(traindata)
dim(testdata)

## ------------------------------------------------------------------------
library(rpart)
library(rpart.plot)
tree<- rpart(Cover_Type ~ ., data = traindata, method = "class", cp=0)
tree
rpart.plot(tree)

## ------------------------------------------------------------------------
printcp(tree)

## ------------------------------------------------------------------------
cp <- tree$cptable[which.min(tree$cptable[,"xerror"]),"CP"]
cp

## ------------------------------------------------------------------------
tree.pruned<-prune(tree, cp=cp)
rpart.plot(tree.pruned)

## ------------------------------------------------------------------------
test.tree<- predict(tree.pruned, testdata, type = "class")
table(testdata$Cover_Type, test.tree)

## ------------------------------------------------------------------------
error<- (1+2+2+13)/ 104
error

## ------------------------------------------------------------------------
set.seed(89)
z<- sample(2, nrow(forest), replace = TRUE, prob = c(0.8,0.2))
traindata<- forest[z==1,]
testdata<- forest[z==2,]

## ------------------------------------------------------------------------
library(randomForest)

## ------------------------------------------------------------------------
rf<- randomForest( Cover_Type ~ ., data = traindata, proximity=TRUE)

## ------------------------------------------------------------------------
print(rf)

## ------------------------------------------------------------------------
importance(rf)

## ----fig6, fig.height=5, fig.width=8-------------------------------------
varImpPlot(rf)

## ------------------------------------------------------------------------
rfpredict<- predict(rf, newdata = testdata)
table(rfpredict, testdata$Cover_Type)

## ------------------------------------------------------------------------
error<- (1+1+9+4)/ 104
error

